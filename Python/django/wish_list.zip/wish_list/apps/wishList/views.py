from django.shortcuts import render, redirect
from .models import User, WishList
from django.contrib import messages

# Create your views here.
def dashboard(request):
    return redirect('login:login')

def index(request):
    u_id = request.session['id']
    context = {
        'name': User.objects.get(id=u_id),
        'user_wishes': WishList.objects.user_items(u_id),
        # 'all_wishes': WishList.objects.all_items(u_id),
    }
    return render(request, 'wishList/index.html', context)
    #create a view page that lists all items in logged in user's wish list in a table
        #make a ORM call to pull all the items from the users list
    #can delete items that logged in user created
        #if user id for item matches the logged user, add button Delete
    #can remove items that logged in user added from others wish list
        #if user id doesn't match the userid for the item, add button Remove from my Wishlist
    #create a table with all the items from others wish lists
    pass

def show(request, id):
    item = Group.objects.get(a_list=id)
    users = Group.objects.filter(a_list=id)
    context = {
        'item': item,
        'users': users,
    }
    #lists a single item with a list of users who also have this item in their db
    return render(request, 'wishList/item.html', context)

def create(request):
    return render(request, 'wishList/new_item.html')

def update(request):
    if request.method == 'POST':
        u_id = request.session['id']
        add_item = WishList.objects.new_item(request.POST, u_id)
        print add_item, '<------- this was returned from .new_item'
        if add_item == True:
            print '<___________ item added successfully'
            messages.success(request, 'Item successfully added')
        else:
            messages.error(request, add_item[1])
            return redirect('wishList:new_item')
    #validations when adding a new item: No Empty entries, should be more than 3 entries
    #should be added to the User's Wish list table
    #User should be redirected to dashboard return redirect('')
    return redirect('wishList:new_item')



def delete_item(request, id):
    pass

def logout(request):
    request.session.clear()
    messages.success(request, 'You have successfully logged out')
    return redirect('login:login')
