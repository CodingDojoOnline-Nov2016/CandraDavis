from __future__ import unicode_literals

from django.db import models
from ..login.models import User

# Create your models here.
class WishListManager(models.Manager):
    def user_items(self, u_id):
        print u_id
        print '<--------in user_items function'
        u_id = User.objects.get(id=u_id)

        user_list = Group.objects.filter(user=u_id)

        print user_list, '<---------here is my list object of items by user_id'
        return user_list

    def all_items(self, u_id):
        print u_id
        print '<--------in all_items function'
        u_id = User.objects.get(id=u_id)
        all_items = User.objects.exclude(id=u_id)
        print all_items
        return all_items

    def new_item(self, data, u_id):
        errors = []
        if len(data['item']) < 1:
            errors.append('Please enter a valid item')
        if not len(data['item']) > 3:
            errors.append('Please enter a valid item')

        if errors:
            print 'So MANY ERRORS!!!!'
            return(False, errors)
        else:
            u_id = User.objects.get(id=u_id)
            item = data['item']
            user = u_id
            item_added = WishList.objects.create(item=item)
            item = Group(user=user, a_list=item_added)
            item.save()
            print item_added, '<------- item added'
            return True

    def delete_item(self, i_id, u_id):
        user = Group.objects.get(user=u_id)
        pass


class WishList(models.Model):
    user = models.ManyToManyField(User)
    item = models.CharField(max_length=45)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)

    objects = WishListManager()

class Group(models.Model):
    user = models.ForeignKey(User)
    a_list = models.ForeignKey(WishList)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)
