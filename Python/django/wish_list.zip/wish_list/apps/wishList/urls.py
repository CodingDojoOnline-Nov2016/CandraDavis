from django.conf.urls import url
from . import views

app_name = 'wishList'

urlpatterns = [
    url(r'^dashboard$', views.index, name='dashboard'),
    url(r'^wish_items/(?P<id>\d+)$', views.show, name='wish_item'),
    url(r'^wish_items/create$', views.create, name='new_item'),
    url(r'^logout$', views.logout, name='logout'),
    url(r'^update$', views.update, name='update'),
    url(r'^delete_item$', views.delete_item, name='delete_item'),
]
#
